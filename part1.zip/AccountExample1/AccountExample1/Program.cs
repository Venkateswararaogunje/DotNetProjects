﻿using System;





class Account
{
    private static int number = 101;
    public readonly int AccountNumber;
    private string _customerName;
    private int _balance;
    public Account(string name, int amount)
    {
        this.AccountNumber = number++;
        this._customerName = name;
        this._balance = amount;
    }
    public int Balance { get { return this._balance; } }
    public string Deposite(int amount)
    {
        this._balance += amount;
        return string.Format("{0} Deposited", amount);
    }
    public string Withdraw(int amount)
    {
        if (this._balance >= amount)
        {
            this._balance -= amount;
        }
        return string.Format("{0} Withdrawal is Successful", amount);
    }

    public string AccountSummary()
    {
        return String.Format("Account Number : {0} \n Customer Name : {1} \n Account Balance : {2}", this.AccountNumber, this._customerName, this._balance);

    }



}

class MainClass
{
    static Account[] accounts = new Account[10];
    static byte counter = 0;
    static Account SearchAccount(int accountNo)
    {
        for (int i = 0; i < counter; i++)
        {
            if (accounts[i].AccountNumber == accountNo)
            {
                return accounts[i];
            }
        }
        return null;
    }
    static void Main()
    {
        byte option, transactionCode;
        char choice;
        Account objAccount = null;
        string name;
        int amount;
        Console.WriteLine("What do u want to Do ");
        Console.WriteLine("1. Create Account\n2.  Transaction in Existing Account\n3. Print All account summary\n4. Exit");

        do
        {
            Console.Write("\nEnter your choice");
            option = byte.Parse(Console.ReadLine());

            switch (option)
            {
                case 1:
                    {
                        Console.WriteLine("Enter Customer Name :");
                        name = Console.ReadLine();
                        Console.WriteLine("Enter Initial Balance: ");
                        amount = int.Parse(Console.ReadLine());
                        accounts[counter++] = new Account(name, amount);
                        Console.WriteLine("Ur account is Successfully Created. Ur Account number is: {0}", accounts[counter - 1].AccountNumber);
                        break;
                    }
                case 2:
                    Console.Write("Enter Account Number: ");
                    int accountNumber = int.Parse(Console.ReadLine());
                    objAccount = SearchAccount(accountNumber);
                    if (objAccount == null)
                    {
                        Console.WriteLine("Please Enter Valid Account Number");
                    }
                    else
                    {
                        Console.WriteLine("\nWhat Operation You wantr To Perform");
                        Console.WriteLine("1. Deposite\n2. Withdraw\n3. Balance Enquiry\n4. Account Summary");
                        Console.WriteLine("Enter Your Transaction Code: ");
                        transactionCode=byte.Parse(Console.ReadLine());
                        switch (transactionCode)
                        {
                            case 1:
                                Console.WriteLine("Enter Amount to Deposite: ");
                                amount = int.Parse(Console.ReadLine());
                                objAccount.Deposite(amount);
                                break;
                            case 2:
                                Console.WriteLine("Enter Amount to Withdraw: ");
                                amount = int.Parse(Console.ReadLine());
                                objAccount.Deposite(amount);
                                break;
                            case 3:
                                Console.WriteLine("Current Balance: " + objAccount.Balance);
                                break;
                            case 4:
                                Console.WriteLine(objAccount.AccountSummary());
                                break;

                        }
                        objAccount = null;

                    }
                    break;
                case 3:
                    Console.WriteLine();
                    for (int i = 0; i < counter; i++)
                    {
                        Console.WriteLine(accounts[i].AccountSummary());
                        Console.WriteLine("--------------------------");
                    }
                    break;

                case 4:
                    Console.WriteLine("Thank You");
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Please enter valid choice");
                    break;


            }

            Console.WriteLine("Do u want to Continue");
            choice = char.Parse(Console.ReadLine());
        } while (choice == 'Y' || choice == 'y');
    }






}