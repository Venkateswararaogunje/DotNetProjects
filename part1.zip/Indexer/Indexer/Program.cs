﻿using System;
namespace Indexer
{
    class Employee
    {
        string[] name = new string[size];
        int[] id = new int[size];
        public static int size = 5;
        public string this[int index]
        {
            get
            {
                if (index >= 0 && index < size)
                {
                    return name[index];
                }
                else
                {
                    return null;
                }
            }
            set
            {
                if (index >= 0 && index < size)
                {
                    name[index] = value;
                }
            }
        }
        public int this[string index]
        {
            get
            {
                for(int i=0;i<size;i++)
                {
                    if (name[i]==index)
                    {
                        return id[i];
                    }
                }
                return 0;
            }
            set
            {
                for(int i=0;i<size;i++)
                {
                    if (name[i]==index)
                    {
                        id[i] = value;
                    }
                }
            }
        }
    }


    class MainClass
    {
        static void Main()
        {
            Employee objEmp = new Employee();

            objEmp[0] = "Venkat";
            objEmp[1] = "Jyothi";
            objEmp[2] = "Kushi";
            objEmp[3] = "Candy";
            objEmp[4] = "Family";
            for(int i =0;i<Employee.size;i++)
            {
                Console.WriteLine(objEmp[i]);
            }
            Console.WriteLine("-----------------");
            objEmp["Venkat"] = 111;
            objEmp["Jyothi"] = 112;
            objEmp["Kushi"] = 113;
            objEmp["Candy"] = 114;
            objEmp["Family"] = 115;
            for(int i=0; i<Employee.size;i++)
            {
                Console.WriteLine(objEmp[objEmp[i]]);
            }
        }
    }
}
