﻿class Employee
{

    private static int id = 421;
    private int _empId;
    private String _empName;
    private int _basic;
    private int _da;
    private int _hra;


    public int EmployeeId
    {
        get
        {
            return this._empId;
        }
    }
    public Employee(String _empName, int _basic, int _da, int _hra)
    {
        this._empId = id++;
        this._empName = _empName;
        this._basic = _basic;
        this._da = _da;
        this._hra = _hra;
    }
    int _employeeSalary = 0;

    public String salaryDetails()
    {
        _employeeSalary = _basic + _da + _hra;
        return String.Format("Employee Id {0}\nEmployee Name {1}\nEmployee Basic Salary {2}\nEmployee DA {3}\nEmployee HRA {4}\nTotal Salary {5}", this._empId, this._empName, this._basic, this._da, this._hra, this._employeeSalary);

    }
}
class MainClass
{
    public static void Main(String[] args)
    {
        String name;
        int basic;
        int da;
        int hra;
        int counter = 0;
        char choice;

        Employee[] emp = new Employee[10];

        Console.WriteLine("Which option you want to choose \n1. Joining in a New Employee\n2. Printing SalarySlip of Existing Employees\n3. Exit");
        do
        {
            Console.WriteLine("Enter your choice");
            byte option = byte.Parse(Console.ReadLine());

            switch (option)
            {

                case 1:
                    Console.WriteLine("Enter Name of Employee");
                    name = Console.ReadLine();
                    Console.WriteLine("Enter Basic Salary of Employee");
                    basic = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter DA ");
                    da = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter HRA");
                    hra = int.Parse(Console.ReadLine());
                    emp[counter++] = new Employee(name, basic, da, hra);
                    Console.WriteLine("Employee {0} Salary Details Updated ", emp[counter - 1].EmployeeId);
                    break;

                case 2:
                    for (int i = 0; i < counter; i++)
                    {
                        Console.WriteLine(emp[i].salaryDetails());
                    }

                    break;

                case 3:
                    Console.WriteLine("Thank you");
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid option");
                    break;

            }
            Console.WriteLine("Would you like to continue (Y/N)");
            choice = char.Parse(Console.ReadLine());
            if (choice == 'N' || choice == 'n')
            {
                Console.WriteLine("Thank you !");
            }
        } while (choice == 'Y' || choice == 'y');


    }
}