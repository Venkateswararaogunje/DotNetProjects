﻿using System;
namespace Interface_AbstractClass
{
    interface Interface1
    {
        void M();
        void N();
    }
    abstract class class1 : Interface1
    {
        void Interface1.M()
        {
            Console.WriteLine("Interface1::M");
        }
        public abstract void N(); 
    }
    class class2 : class1
    {
        public override void N()
        {
            Console.WriteLine("class2::N");
        }
    }
    class MainClass
    {
        static void Main()
        {
            Interface1 i1 = new class2();
            i1.M();
            i1.N();
        }
    }
}
