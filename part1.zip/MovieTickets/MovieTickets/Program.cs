﻿interface Movie
{
    void Draw();
}
class Vikram : Movie
{
    public void Draw()
    {
        Console.WriteLine("Releasing Vikram");
    }
}
class Sahoo : Movie
{
    public void Draw()
    {
        Console.WriteLine("Releasing Sahoo");
    }
}
class Avatar : Movie
{
    public void Draw()
    {
        Console.WriteLine("Releasing Avatar");
    }
}
class Mainclass
{
    static void Main()
    {
        Movie[] moviename = new Movie[3];
        moviename[0] = new Vikram();
        moviename[1] = new Sahoo();
        moviename[2] = new Avatar();

        foreach (Movie s in moviename)
        {
            s.Draw();
        }
    }
}