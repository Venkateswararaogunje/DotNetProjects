﻿using System;


namespace AccountExample
{

    internal class Account
    {
        private int nbr = 369;
        private int _accNo;
        private string _accName;
        private int _balance;

        public Account(string name, int bal)
        {
            this._accNo = nbr++;
            this._accName = name;
            this._balance = bal;
        }
        public int Balance
        {
            get
            {
                return this._balance;
            }
        }
        public string AccSummary()
        {
            return string.Format("Acc No: {0}\nacc Name :{1}\nbalance:{2}", this._accNo, this._accName, this._balance);
        }
        public void Deposit(int amount)
        {
            this._balance = this._balance + amount;
            return string.Format("{0} deposited", amount);
        }
        public void Withdraw(int amount)
        {
            if (this._balance >= amount)
            {
                this._balance -= amount;
            }
            return string.Format("{0} withdraw", amount);
        }

    }

    class MainClass
    {
        static void main()
        {
            Account objAccount = new Account("vj", 2210);
            objAccount.Deposit(1999);
            objAccount.Withdraw(2222);
            Console.WriteLine(objAccount.Balance);
            Console.WriteLine(objAccount.AccSummary());

        }
    }

}
