﻿
interface Interface1
{
    public void M();
}
interface Interface2 : Interface1
{
    new void M(); void N();
}
class Class1 : Interface1, Interface2//Implementing Interface Not
{
    void Interface1.M()
    {
        Console.WriteLine("Interface1 M Implementation");
    }
    public void M()
    {
        Console.WriteLine("Interface2 M Implementation");
    }

    public void N()
    {
        Console.WriteLine("This is also common");
    }
    class Mainclass
    {
        static void Main()
        {
            Class1 c1 = new Class1();
            Interface1 i1 = c1;
            Interface2 i2 = c1;
            i1.M();
            i2.M();
        }
    }
}

