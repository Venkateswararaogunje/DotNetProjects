﻿namespace lio
{
    enum Country
    {
        India = 1,
        Australia,
        US,
        UK,
        China,
        Japan,
        Canada,
        Brazil,
        Spain
    }
    class MainClass
    {
        static void Main()
        {

            Console.WriteLine("For which Country You Want to Know Language");
            Console.WriteLine("1.India\n2.Australia\n3.US\n4.UK\n5.Chaina\n6.Japan\n7.Canada\n8.Brazil\n9.Spain");
            Console.WriteLine("Please Enter your Choice: ");
            byte choice = byte.Parse(Console.ReadLine());
            Country c = (Country)choice;


            switch (c)
            {
                case Country.Australia:
                case Country.UK:
                case Country.US:
                case Country.India:
                    Console.WriteLine("Language Spoken in {0} is English", c);
                    break;
                case Country.Brazil:
                    Console.WriteLine("Language Spoken in {0} is Brazilian", c);
                    break;
                case Country.China:
                    Console.WriteLine("Language Spoken in {0} is Chinese", c);
                    break;
                case Country.Japan:
                    Console.WriteLine("Language Spoken in {0} is Japanise", c);
                    break;
                case Country.Spain:
                    Console.WriteLine("Language Spoken in {0} is Spanish", c);
                    break;
                case Country.Canada:
                    Console.WriteLine("Language Spoken in {0} is Canadian", c);
                    break;
                default:
                    Console.WriteLine("Invalid choise", c);
                    break;





                }


        }
    }
}