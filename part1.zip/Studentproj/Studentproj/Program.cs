﻿using System;

class Student
{
    public virtual void print()
    {
        Console.WriteLine("print the student");
    }
}
class Artsstudent : Student
{
    public override void print()
    {
        Console.WriteLine("print the Artsstudent");
    }
}
class Sciencesstudent : Student
{
    public override void print()
    {
        Console.WriteLine("print the Sciencestudent");
    }
}
class Mathsstudent : Student
{
    public override void print()
    {
        Console.WriteLine("print the Mathsstudent");
    }
}
class Mainclass
{
    static void Main()
    {
        Student[] Classstudents = new Student[3];
        Classstudents[0] = new Artsstudent();
        Classstudents[1] = new Sciencesstudent();
        Classstudents[2] = new Mathsstudent();

        foreach (Student s in Classstudents)
        {
            s.print();
        }
    }

}