﻿
using System;
namespace ProtectedExplanation
{
    class class1
    {
        protected virtual void M()
        {
            Console.WriteLine("class1::M");
        }
    }
    class class2 : class1
    {
        protected new void M()
        {
            Console.WriteLine("class2::M");
        }
        public void P()
        {
            class1 c1 = new class2();
            Console.WriteLine("c1ass2.P");
            base.M();
            this.M();
        }
    }
    class MainClass
    {
        static void Main()
        {
            class1 c1 = new class1();//c1.M();
            class2 c2 = new class2();//c2.M();
            c1 = c2;//c1.M();
            c2.P();
        }
    }
}


