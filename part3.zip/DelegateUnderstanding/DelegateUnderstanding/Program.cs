﻿using System;
namespace DelegateUnderstanding
{
    class MainClass
    {
        static void Main()
        {
            Customer cust = new Customer(101, "venkat");
            Product prod = new Product(111, "Rohit");
            Employee emp = new Employee(2051, "venkat", 12000, 10000, 8000);
            cust.AvailService();
            Console.WriteLine("-----------------");
            prod.UseService();
            Console.WriteLine("-----------------");
            emp.GenerateSalarySlip();
        }
    }
}