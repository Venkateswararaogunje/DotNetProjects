﻿using System;
namespace DelegateUnderstanding
{
    class Customer
    {
       
    }
}
