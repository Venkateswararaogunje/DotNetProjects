﻿using System;

namespace DelegateUnderstanding
{
    class PrintingService
    {
        
    }
}