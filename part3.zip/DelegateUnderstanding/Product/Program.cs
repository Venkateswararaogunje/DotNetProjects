﻿using System;
namespace DelegateUnderstanding
{
    class Product
    {
 }
    }
}
