﻿using System;
namespace DelegateUnderstanding
{
    class Employee
    {
        

    }
}