﻿using System;
using System.Threading;
namespace Threads
{
    class Mainclass
    {
        public static void M()
        {
            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine("Thread M:{0}", i + 1);
            }
        }
        public static void N()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Thread Another:{0}", i + 1);
            }
        }
        public static void P(object s)
        {
            Console.WriteLine("Hello" + (string)s);
        }



        static void Main()
        {
            Thread t1 = new Thread(new ThreadStart(M));
            Thread t2 = new Thread(N);
            t1.IsBackground = true;
            t1.Start();
            t2.Start();
            Console.WriteLine("checking whether T1 is Background Thread:" + t1.IsBackground);
            t1.Abort();
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("Thread Main:{0}", i);
            }
            //t1.Join();
            Console.WriteLine("-----------------");
            Console.WriteLine("im saying lie about kiran !");
            Thread t3 = new Thread(new ParameterizedThreadStart(P));
            Console.WriteLine("Kiran is good boy");
            Console.WriteLine("------------------------");



        }



    }
}