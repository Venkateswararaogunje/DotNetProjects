﻿using System;
namespace IComparableRevision
{
    class Employee : IComparable
    {
        private int _salary;
        public Employee(int salary)
        {
            this._salary = salary;
        }
        public int CompareTo(object e2)
        {
            return this._salary.CompareTo(((Employee)e2)._salary);
        }
    }
}