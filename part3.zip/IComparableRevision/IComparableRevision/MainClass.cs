﻿using System;

namespace IComparableRevision
{
    class MainClass
    {
        static void Main()
        {
            int x = 30, y = 20;
            Console.WriteLine(x.CompareTo(y));

            Employee emp1 = new Employee(1500);
            Employee emp2 = new Employee(12000);
            Console.WriteLine(emp1.CompareTo(emp2));
            Student[] yourArray = new Student[5];
            yourArray[0] = new Student(50);
            yourArray[1] = new Student(10);
            yourArray[2] = new Student(40);
            yourArray[3] = new Student(30);
            yourArray[4] = new Student(20);

            Array.Reverse(yourArray);
            Utilities.Sort(yourArray);
            foreach(Student s in yourArray)
            {
                Console.Write(s.Marks + " ");
            }
            Console.WriteLine();

            int[] intArray = { 50, 10, 40, 30, 20 };
            Array.Reverse(intArray);
            Utilities.Sort(intArray);
            foreach(int i in intArray)
            {
                Console.Write(i + " ");
            }
        }
    }
}
