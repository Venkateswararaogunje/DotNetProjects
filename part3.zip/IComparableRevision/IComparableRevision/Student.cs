﻿using System;

namespace IComparableRevision
{
     public struct Student : IComparable

    {
        private int _marks;
        public Student(int marks)
        {
            this._marks = marks;
        }
        public int CompareTo(object s)
        {
            return this.Marks.CompareTo(((Student)s).Marks);
        }
        public int Marks
        {
            get { return this._marks; }
        }
    }
}
