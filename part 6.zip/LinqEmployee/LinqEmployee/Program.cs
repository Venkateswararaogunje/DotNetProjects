﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Linq;
using System.Data.SqlClient;

namespace LinqEmployee
{
    class Program
    {
       static void EmpDepTwoTableQuery()
        {
            EmployeeDataSet eds = new EmployeeDataSet();
            EmployeeDataSetTableAdapters.EmployeesTableAdapter empTableAdapter = new EmployeeDataSetTableAdapters.EmployeesTableAdapter();
            empTableAdapter.Fill(eds.Employees);

            EmployeeDataSetTableAdapters.DepartmentsTableAdapter depTableAdapter= new EmployeeDataSetTableAdapters.DepartmentsTableAdapter();
            depTableAdapter.Fill(eds.Departments);

            var query = from emp in eds.Employees
                        join dep in eds.Departments on emp.DID equals dep.DID
                        orderby emp.ID
                        select new
                        {
                            EmployeeID = emp.ID,
                            EmployeeName = emp.Name,
                            EmployeeDepartment = dep.DID,
                            EmployeeDepartmentName = dep.DeptName,
                            EmployeeSalary = emp.Salary,
                        };
            foreach(var item in query)
            {
                Console.WriteLine(item.EmployeeID);
                Console.WriteLine(item.EmployeeName);
                Console.WriteLine(item.EmployeeDepartment);
                Console.WriteLine(item.EmployeeDepartmentName);
                Console.WriteLine(item.EmployeeSalary);

            }
           
        }
        static void Main()
        {
            EmpDepTwoTableQuery();
        }
    }
}
