﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            MyDAL  MyData = new MyDAL();
            Person p = new Person();
            p.ID = 101;
            p.Name = "Venakt";
            p.City = "hyderabad";
            p.Country = "India";
            MyData.Persons.Add(p);
            Console.WriteLine("--------------------");
        }
    }
}
