﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqToSql
{
    class MainClass

    {
        
        
        
        static MindtreeDBDataContext db = new MindtreeDBDataContext();
        static void InsertEmployees(Employee emp)
        {
            db.Employees.InsertOnSubmit(emp);

        }
        static List<Employee> SelectEmployee()
        {
            return (from emp in db.Employees select emp).ToList<Employee>();
                    
        }
         static void Main()
        {
            //MindtreeDBDataContext db = new MindtreeDBDataContext();
            //var EmployeesQuery = from emp in db.Employees
            //                     where emp.Salary < 12200
            //                     select emp;
            foreach(var e in SelectEmployee())
            {
                Console.WriteLine("ID={0}", e.ID);
                Console.WriteLine("Name={0}", e.Name);
                Console.WriteLine("Salary={0}", e.Salary);
                Console.WriteLine("Department={0}", e.DID);



            }
            Employee emp1 = new Employee();
            emp1.ID = 144;
            emp1.Name = "Venkat";
            emp1.Salary = 1000;
            emp1.DID = 2;
            InsertEmployees(emp1);

            //db.SubmitChanges();
            Console.ReadKey();
        }
    }
}
