﻿using System;


namespace GarbageCollection
{
    public class Mainclass
    {
        public static void Main(string[] args)
        {
            using (Employee e1 = new Employee(1))
            {
                e1.Salary = 10000;
                e1.WorkStatus();
                e1.IncrementSalary(20000);
            }
            using (Employee e2 = new Employee(1))
            {
                e2.Salary = 10000;
                e2.WorkStatus();
                e2.IncrementSalary(20000);
            }
            Console.WriteLine("---------------");
        }
    }
}
