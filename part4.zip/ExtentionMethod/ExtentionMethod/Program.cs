﻿using System;



namespace ExtensionMethod
{
    public static class MyExtensions
    {
        public static int Toint32(this string s)
        {
            return int.Parse(s);
        }
    }
    class MainClass
    {
        static void Main()
        {
            string str = "1234";
            int i = str.Toint32();
            Console.WriteLine(i);




        }
    }
}
