﻿using System;
using System.Collections.Generic;



public class Employee : IComparable<Employee>
{
    public int Empid { get; set; }
    public string EmpName { get; set; }
    public double EmpSalary { get; set; }

    public int CompareTo(Employee otherEmp)
    {
        if (this.EmpSalary > otherEmp.EmpSalary) { return 1; }
        else if (this.EmpSalary < otherEmp.EmpSalary) { return -1; }
        else { return 0; }
    }

    public override string ToString()
    {
        return String.Format(Empid + " " + EmpName + " " + EmpSalary);
    }


    public static void Main(string[] args)
    {
        List<Employee> emp = new List<Employee>()
            {

                    new Employee{Empid=101,EmpName="Cc",EmpSalary=5000},
                    new Employee{Empid=102,EmpName="Bb",EmpSalary=6000},
                   new Employee{ Empid=103,EmpName="Dd",EmpSalary=7000},
                    new Employee{Empid=104,EmpName="Aa",EmpSalary=35000},
                    new Employee{Empid=105,EmpName="Ee",EmpSalary=20000},





               };
        var empList = emp;
        // IEnumerable<Employee> result =emp.Where(x=>x.name[0]=='S');
        //  foreach(Employee e in result){


        Console.WriteLine(" ************ All Employee Details ************ ");
        IEnumerable<Employee> ienum = (IEnumerable<Employee>)empList;
        foreach (Employee i in ienum)
        {
            Console.WriteLine(i.ToString());
        }

        Console.WriteLine("Employee Details whose salary is less than 10000");

        foreach (Employee i in ienum)
        {
            //var query = empList.Where(b => b.getId() == p.getId()).ToList();
            if (i.EmpSalary < 10000)
            {
                Console.WriteLine(i.ToString());
            }

        }

        Console.WriteLine(" Sort all employees based on their salary and Print all employees details after sorting");
        empList.Sort();
        IEnumerable<Employee> ienumsorted = (IEnumerable<Employee>)empList;
        foreach (Employee i in ienumsorted)
        {
            Console.WriteLine(i.ToString());
        }
        Console.WriteLine(" Remove all employees whose salary is more than 30000 and print all employees present in list");
        //IEnumerable<Employee> ienumremoving = (IEnumerable<Employee>)empList;
        for (int i = 0; i < 5; i++)
        {
            if (empList[i].EmpSalary > 30000)
            {
                empList.Remove(empList[i]);
            }
        }
        Console.WriteLine(" --------");
        IEnumerable<Employee> ienumremove = (IEnumerable<Employee>)empList;
        foreach (Employee i in ienumremove)
        {
            Console.WriteLine(i.ToString());
        }


    }
}
