﻿using System;

namespace ReverseWord
{
    class Mainclass
    {
        static void Main(string[] args)
        {
            string str, reverse = "";

            Console.WriteLine("Enter a word:");
            str = Console.ReadLine();
            str = str.ToLower();
            for (int i = str.Length - 1; i >= 0; i--)
            {
                reverse = reverse + str[i];

            }
            Console.WriteLine("Reverse word is:{0}", reverse);
            Console.ReadLine();



        }
    }
}