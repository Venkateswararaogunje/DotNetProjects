﻿using System;
namespace Celsius
{
    class temperature
    {
        static void Main(string[] args)
        {
            float celsius;
            Console.Write("Enter Fahrenheit temperature : ");
            float fahrenheit = float.Parse(Console.ReadLine());
            celsius = (fahrenheit - 32) * 5 / 9;
            Console.WriteLine("The Celsius temperature is" + celsius);
            Console.ReadLine();
        }
    }
}