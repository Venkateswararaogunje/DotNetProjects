﻿using System;

namespace SameWords
{
    class MainClass
    {
        static void Main()
        {
            Console.WriteLine("Enter Word : ");
            string w1 = Console.ReadLine();
            Console.WriteLine(w1.Length);
        }
    }
}
