﻿
using System;
namespace Demo
{
    class check
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.WriteLine("enter the first number:");
            num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the Second number:");
            num2 = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the Third number:");
            num3 = int.Parse(Console.ReadLine());
            if (num1 > num2)
            {
                if (num1 > num3)
                {
                    Console.Write("First number is the largest!");
                }
                else
                {
                    Console.Write("third number is the largest!");
                }
            }
            else if (num2 > num3)
                Console.Write("second number is the largest!");
            else
                Console.Write("third number is the largest!");
            if (num1 < num2)
            {
                if (num1 < num3)
                {
                    Console.Write("First number is the smallest!");
                }
                else
                {
                    Console.Write("third number is the smallest!");
                }
            }
            else if (num2 < num3)
                Console.Write("second number is the smallest!");
            else
                Console.Write("third number is the smallest!");
        }
    }
}


