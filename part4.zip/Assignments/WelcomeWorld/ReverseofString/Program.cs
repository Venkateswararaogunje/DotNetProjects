﻿
using System;

namespace SameWords
{
    class MainClass
    {
        static void Main()
        {
            Console.WriteLine("Enter Word want to reverse : ");
            string w = Console.ReadLine();
            string rev = "";
            int a = w.Length-1 ;
            while (a > 0)
            {
                rev = rev + w[a];
                a--;
            }
            Console.WriteLine("Reversed word is : {0} ", rev);
        }
    }
}