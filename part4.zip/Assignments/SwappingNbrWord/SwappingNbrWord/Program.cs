﻿using System;
public class Swap
{
    public static void SwapNumber(int a, int b)
    {
        int swap;
        swap = a;
        a = b;
        b = swap;
        Console.WriteLine("After Swapping : ");
        Console.WriteLine("First Number :{0} ", a);
        Console.WriteLine("Second Number :{0} ", b);




    }
    public static void SwapName(string p, string q)
    {
        Console.WriteLine("Strings before swap: p =" +
                          " " + p + " and q = " + q);
        p = p + q;

        // store initial string a in string b
        q = p.Substring(0, p.Length - q.Length);

        // store initial string b in string a
        p = p.Substring(q.Length);
        Console.WriteLine("Strings after swap: p =" +
                         " " + p + " and q = " + q);
    }
    public static void Main(string[] args)
    {
        SwapNumber(3, 5);
        SwapName("Hello", "World");


    }
}