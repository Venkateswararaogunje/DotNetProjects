﻿using System;
using System.Collections;
namespace CSIterators
{
    class MainClass
    {
        public static IEnumerable GetAllUsers()
        {
            yield return 1;
            yield return 2;
            yield return 3;
        }
        static void Main()
        {
            foreach (int i in GetAllUsers())
            {
                Console.WriteLine(i);   
            }
            string name = "Venkat";
            IEnumerable e = name;
            IEnumerator en = e.GetEnumerator();
            while (en.MoveNext())
            {
                Console.WriteLine(en.Current);
            }

                en.Reset();
            while(en.MoveNext())
             {
                Console.WriteLine(en.Current);

                }
             foreach(char c in name)
            {
                Console.WriteLine(c);
            }
            
        }

    }
}
