﻿using System;
namespace PartialMethos
{
    partial class MYPartialClass
    {
        partial void M();
        static partial void N();
        
    }
}