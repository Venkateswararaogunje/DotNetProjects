﻿using System;


namespace PartialMethos
{
    class MainClass
    {
        static void Main()
        {
            MYPartialClass p = new MYPartialClass();
            p.CallNonStaticMethod();
            MYPartialClass.CallStaticMethod();
        }
    }
}
