﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SerializationStudent
{
    public class Student
    {
        public int id;
        public string name;



        //[NonSerialized]
        private int _marks;
        //[NonSerialized]
        private int _age;



        public Student()
        {



        }



        public Student(int sid, string sname, int smarks, int sage)
        {
            id = sid;
            name = sname;
            _marks = smarks;
            _age = sage;
        }
        public int age
        {
            get
            {
                return _age;
            }
        }
        public int marks
        {
            get
            {
                return _marks;
            }
        }





    }
}
