﻿using System;
namespace ObjectInitializer
{
    class Person
    {

        public int Age { get; set; }
        public string Name { get; set; }
        public string City;
        public Person()
        {
            Console.WriteLine("Default");
        }
    }
    class MainClass
    {
        static void Main()
        {
            Person p = new Person { Age = 34, Name = "Venkat", City = "Nidadavolu" };
            p.Age = 30; p.Name = "SaiKIran";

            Console.WriteLine("Age={0}, Name = {1}, City={2}", p.Age, p.Name, p.City);

        }
    }
}