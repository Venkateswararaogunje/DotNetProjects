﻿using System;
namespace IComprarableExplanation
{
    struct student : IComparable
    {
        public int marks;
        public int CompareTo(object obj)
        {
            student s = (student)obj;
            return this.marks.CompareTo(s.marks);
        }
        public override string ToString()
        {
           
                return this.marks.ToString();
        }
    }
    class MainClass
    {
        static void Main()
        {
            int i = 10, j = 20;
            Console.WriteLine(i.CompareTo(j));
            student s, p;
            s.marks = 10;
            p.marks = 20;
            Console.WriteLine("---------------");
            int[] intArray = new int[5] { 20, 10, 50, 30, 40 };
            Array.Sort(intArray);
            foreach(int k in intArray)
            {
                Console.WriteLine(k+" ");
            }
            Console.WriteLine("\n--------------");
            student[] students = new student[5];
            students[0].marks = 20;
            students[1].marks = 10;
            students[2].marks = 50;
            students[3].marks = 30;
            students[4].marks = 40;
            Array.Sort(students);
            foreach(student stud in students)
            {
                Console.Write(stud.marks + " ");
            }
            IComparable[] myArray = new IComparable[5];
            myArray[0] = students[0];
            myArray[1] = students[1];
            myArray[2] = students[2];
            myArray[3] = students[3];
            myArray[4] = students[4];
            Array.Sort(myArray);
            foreach (student stud in myArray)
            {
                Console.Write(stud + " ");
            }
        }
    }
}