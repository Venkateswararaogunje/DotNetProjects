﻿using System;
using System.Collections;

namespace IEnumerableExplanation
{
    class MainClass
    {
        static void Main()
        {
            int[] intArray = new int[5] {1, 2, 3, 4, 5 };
            foreach (int i in intArray)
            {
                Console.Write(i+" ");
            }
            Console.WriteLine("\n------------------------");
            IEnumerator t = intArray.GetEnumerator();
            while(t.MoveNext())
            {
                Console.WriteLine(t.Current + " ");
            }
            t.Reset();
            Console.WriteLine("\n-----------------");
            IEnumerable en = intArray;
            foreach(int i in en)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine("\n-----------");
            t = en.GetEnumerator();
            while(t.MoveNext())
            {
                Console.Write(t.Current + " ");
            }
            t.Reset();
            Console.WriteLine("\n------------------");
        }
    }
}