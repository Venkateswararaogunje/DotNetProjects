﻿using System;
using System.Collections;

namespace StackAndQueue
{
    class MainClass
    {
        static void Main()
        {
            Queue b=new Queue();    
            Stack s=new Stack();
            s.Push(3);
            s.Push(4);
            s.Push(5);
            int topStack = s.Pop();
            Console.WriteLine(topStack);
            s.Push(10);
            Console.WriteLine("-------------------");
            foreach(int i in s)
            {
                Console.WriteLine(i);
            }

            
        }
    }
}