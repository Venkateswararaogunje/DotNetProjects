﻿using System;
using System.Collections;

   class MainClass
    {
        static void Main()
        {
            Stack s = new Stack();
            s.Push("Venkat");
            s.Push("Rao");
            s.Pop();
            s.Push("Saikiran");

            
            foreach (var o in s)
            {
                Console.WriteLine(o);
            }
        }
    }