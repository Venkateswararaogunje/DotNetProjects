﻿using System;
using System.Collections;

namespace HashtableExample
{
    class MainClass
    {
         static  void Main()
        {
            Hashtable h = new Hashtable();
            h.Add(1, "Venkat");
            h.Add(2, "Rao");
            h.Add(5, "Triandh");
            h.Add(4, "kiran");
            h.Add(6, "prakash");
            h.Add(3, "Chaitamya");
            foreach(object o in h.Values)
            {
                Console.WriteLine(o);
            }
            Console.WriteLine("--------------");
            foreach(int i in h.Keys)
            {
                Console.WriteLine(h[i]);
            }
        }
    }
}
