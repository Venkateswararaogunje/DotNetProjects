﻿
using System;
using System.Collections;
using System.Collections.Generic;



public class MainClass
{
    public static void UsingArrayList()
    {
        ArrayList a1 = new ArrayList(3);
        a1.Add(3);
        a1.Add("Venkat");
        a1.Add(new object());
        a1.Add("Saibaba");
        a1.Add(24);

        foreach (object o in a1)
        {
            Console.WriteLine(o);
        }
        Console.WriteLine("\n Capacity: " + a1.Capacity);
        Console.WriteLine("Count: " + a1.Count);
    }
    public static void UsingGenericList()
    {
        List<int> intList = new List<int>();
        intList.Add(10);
        intList.Add(30);
        intList.Add(50);
        intList.Add(20);
        foreach (int i in intList)
        {
            Console.WriteLine(i);
        }
    }
    public static void Main(string[] args)
    {
        UsingArrayList();
        UsingGenericList();
    }
}



